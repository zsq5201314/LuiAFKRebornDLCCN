using Terraria.ModLoader;

namespace LuiAFKRebornDLCCN
{
	public class LuiAFKRebornDLCCN : Mod
	{
	}
}